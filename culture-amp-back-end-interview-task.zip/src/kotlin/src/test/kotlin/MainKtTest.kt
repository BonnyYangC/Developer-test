import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.io.PrintStream


class MainKtTest {
    @Test
    fun testParticipation() {
        val output = ByteArrayOutputStream()
        val outputStream = PrintStream(output)
        val error = ByteArrayOutputStream()
        val errorStream = PrintStream(error)
        val file = "../../example-data/survey.csv"

        runAnalysis(file, outputStream, errorStream)

        val expectedParticipationResult = """
      Participation

      Participants: 6
      Submitted: 5 (83.3%)

      I like the kind of work I do. 4.6
      In general, I have the resources (e.g., business tools, information, facilities, IT or functional support) I need to be effective. 5.0
      We are working at the right pace to meet our goals. 5.0
      I feel empowered to get the work done for which I am responsible. 3.6
      I am appropriately involved in decisions that affect my work. 3.6"""
        assertEquals(expectedParticipationResult, output.toString());
    }
}