import java.io.OutputStream
import java.io.PrintStream

fun main(args: Array<String>) {
    if (args.size != 1) {
        println("Usage: java -jar survey-tool.jar <file path>")
        throw IllegalArgumentException()
    }
    val file = args[0]

    runAnalysis(file, System.out, System.err)
}

fun runAnalysis(file: String, outputStream: OutputStream, errorStream: OutputStream) {
    // Your implementation goes here
    val result = ""
    PrintStream(outputStream).print(result)
}
