
rootProject.name = "surveyToolKotlin"

