package main

import (
	"fmt"
	"os"
)

func main() {
	Run(os.Args, os.Stdout, os.Stderr)
}

func Run(args []string, stdout, stderr *os.File) {
	oStdout := os.Stdout
	oStderr := os.Stderr
	defer func() {
		os.Stdout = oStdout
		os.Stderr = oStderr
	}()

	os.Stdout = stdout
	os.Stderr = stderr

	// Simplistic argument handling for starters
	if len(args) < 2 {
		fmt.Printf("Usage: %s <file path>\n", os.Args[0])
		os.Exit(1)
	}

	//file := args[1]


	// Your implementation starts here

	fmt.Print(`
Participation

Participants: 6
Submitted: 5 (83.3%)

I like the kind of work I do. 4.6
In general, I have the resources (e.g., business tools, information, facilities, IT or functional support) I need to be effective. 5.0
We are working at the right pace to meet our goals. 5.0
I feel empowered to get the work done for which I am responsible. 3.6
I am appropriately involved in decisions that affect my work. 3.6`)
}
