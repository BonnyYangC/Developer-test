# Survey Tool - Python3

_Please review the [main README](../../README.md) for overall instructions._

Welcome to the Python3 starter kit for the survey tool exercise!

Included here is a simple `main.py` with a `main()` function for invoking the application
as a CLI, and a separate `Run` function for holding the beginnings of your application
logic. There’s also a lightweight table test defined in `test_main.py` which should
help you drive the beginning of your implementation.

## Prerequisites

- Python 3.12.2

## Development


### Testing

``` sh
python3 -m unittest test_main.py
```

### Running

``` sh
python3 main.py
```
