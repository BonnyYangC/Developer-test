import os
import sys



def run(args):

    # Simplistic argument handling for starters
    if len(args) != 2:
        print(f"Usage: {args[0]} <file path>")
        sys.exit()

    file = args[1]

    # Your implementation starts here

if __name__ == '__main__':
    run(sys.argv)