import unittest
import sys
import io

from main import run


class MainTest(unittest.TestCase):

    def test_participation(self):
        """When valid inputs are supplied for the participation command"""

        file = "../../example-data/survey.csv"
        args = ["test_main.py", file]

        captured_output = io.StringIO()
        sys.stdout = captured_output

        run(args)

        expected_participation_result = """
      Participation

      Participants: 6
      Submitted: 5 (83.3%)

      I like the kind of work I do. 4.6
      In general, I have the resources (e.g., business tools, information, facilities, IT or functional support) I need to be effective. 5.0
      We are working at the right pace to meet our goals. 5.0
      I feel empowered to get the work done for which I am responsible. 3.6
      I am appropriately involved in decisions that affect my work. 3.6
"""
        self.assertEqual(captured_output.getvalue(), expected_participation_result)

        sys.stdout = sys.__stdout__

if __name__ == '__main__':
    unittest.main()
