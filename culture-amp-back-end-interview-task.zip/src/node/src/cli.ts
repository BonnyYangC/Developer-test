export default function call(_arguments: string[]): string {
  // Your implementation starts here
  return ''
}