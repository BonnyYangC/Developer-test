# Survey Tool - Java

_Please review the [main README](../../README.md) for overall instructions._

Welcome to the Java starter kit for the survey tool exercise!

Included here is a simple `main.java` with a `main()` function for invoking the application
as a CLI, and a separate `runAnalysis` function for holding the beginnings of your application
logic. There’s also a lightweight integration test defined in `MainTest.kt` which should
help you drive the beginning of your implementation.

## Prerequisites

- OpenJDK 17+

## Development
Using an IDE like IntelliJ simplifies development. 
If you want to run things on the command line, you can use the following process. 

### Building the code into a jar

Note the tests don't initially pass, so this skips them
``` sh
./gradlew build -x test
```

### Testing

Note, the tests initially fail
``` sh
./gradlew test
```

### Running

To run a single file java project, you can simply

```shell
./gradlew run -x test --args "../../example-data/survey.csv"
```

Or, if it's already built

```shell
java -classpath ./build/libs/surveyToolJava-1.0-SNAPSHOT.jar Main ../../example-data/survey.csv
```