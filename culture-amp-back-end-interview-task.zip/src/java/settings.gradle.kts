
rootProject.name = "surveyToolJava"

