import java.io.OutputStream;
import java.io.PrintStream;

public class Main {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java src/main/java/Main.java <file path>");
            throw new IllegalArgumentException();
        }
        final String file = args[0];

        new Main().runAnalysis(file, System.out, System.err);
    }

    void runAnalysis(final String file, final OutputStream outputStream, final OutputStream errorStream) {
        // Your implementation goes here
        final String result = "";
        new PrintStream(outputStream).print(result);
    }
}